Place PNG-based 2D LUT files here (e.g., lut_33.png) or 3D LUT data. The app includes a CPU LUT loader
that maps colors through a PNG LUT (assumes standard cube-slice arrangement). For best results, export
a 33x33x33 >= PNG LUT from tools like 3D LUT Creator or DaVinci Resolve.
