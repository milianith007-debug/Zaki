package com.example.iphone17procamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.SelfieSegmenter
import com.google.mlkit.vision.segmentation.SelfieSegmenterOptions
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureBtn: Button
    private lateinit var toggleBokehBtn: Button
    private lateinit var applyLutBtn: Button

    private var useBokeh = true
    private lateinit var imageCapture: ImageCapture
    private lateinit var cameraExecutor: ExecutorService

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms[Manifest.permission.CAMERA] == true) startCamera() else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        captureBtn = findViewById(R.id.buttonCapture)
        toggleBokehBtn = findViewById(R.id.buttonToggleBokeh)
        applyLutBtn = findViewById(R.id.buttonApplyLUT)

        cameraExecutor = Executors.newSingleThreadExecutor()

        toggleBokehBtn.setOnClickListener {
            useBokeh = !useBokeh
            toggleBokehBtn.text = "Bokeh: ${'$'}{if (useBokeh) "On" else "Off"}"
        }

        captureBtn.setOnClickListener { takePhoto() }
        applyLutBtn.setOnClickListener { /* This button toggles applying LUT on saved photos in gallery - placeholder */ }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        } else startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build()
            imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            val selector = CameraSelector.DEFAULT_BACK_CAMERA

            preview.setSurfaceProvider(previewView.surfaceProvider)
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, selector, preview, imageCapture)
            } catch (e: Exception) { Log.e("Camera", "bind failed", e) }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val outFileOptions = ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "iphone17look_${System.currentTimeMillis()}")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            }
        ).build()

        imageCapture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                // Convert to Bitmap
                val bmp = imageProxyToBitmap(image)
                image.close()
                if (bmp == null) return

                // Run segmentation and post-process
                runSegmentationAndFinish(bmp)
            }
            override fun onError(exc: ImageCaptureException) { Log.e("Camera", "Capture failed: ${'$'}exc") }
        })
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        val plane = image.planes[0]
        val buffer: ByteBuffer = plane.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        // This simplistic conversion may not work for all formats; we assume JPEG capture here isn't used.
        try {
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) { Log.e("Conv", "toBitmap failed", e) }
        return null
    }

    private fun runSegmentationAndFinish(photo: Bitmap) {
        val options = SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        val segmenter = SelfieSegmenter.getClient(options)
        val image = InputImage.fromBitmap(photo, 0)
        segmenter.process(image).addOnSuccessListener { mask ->
            val final = PostProcessor.applyLookAndBokeh(photo, mask, useBokeh)
            // Save final to MediaStore
            saveBitmapToGallery(final)
        }.addOnFailureListener { e ->
            Log.e("Seg", "Segmentation failed", e)
            val final = PostProcessor.applyLookAndBokeh(photo, null, useBokeh)
            saveBitmapToGallery(final)
        }
    }

    private fun saveBitmapToGallery(bmp: Bitmap) {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "iphone17look_${System.currentTimeMillis()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 92, out) }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
