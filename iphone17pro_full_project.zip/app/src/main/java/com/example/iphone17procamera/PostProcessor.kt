package com.example.iphone17procamera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.google.mlkit.vision.segmentation.SegmentationMask
import java.nio.ByteBuffer
import kotlin.math.min

object PostProcessor {
    // Simple pipeline: color grade via ColorMatrix + optional background blur using mask
    fun applyLookAndBokeh(src: Bitmap, mask: SegmentationMask?, useBokeh: Boolean): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)

        // 1) Color grade (simple matrix & contrast/saturation tweaks)
        val finn = ColorGrader.applySimpleFilmLook(bmp)

        // 2) If mask + bokeh -> blur background and composite
        if (useBokeh && mask != null) {
            val blurred = fastBlur(finn, radius = 18)
            return compositeForegroundBackground(finn, blurred, mask)
        }
        return finn
    }

    private fun compositeForegroundBackground(foreground: Bitmap, background: Bitmap, mask: SegmentationMask): Bitmap {
        val w = foreground.width
        val h = foreground.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint()

        // Convert mask buffer (float confidence) to alpha per pixel
        val buf: ByteBuffer = mask.buffer
        buf.rewind()
        val mw = mask.width
        val mh = mask.height
        // Scale mask to image size
        val maskBmp = Bitmap.createBitmap(mw, mh, Bitmap.Config.ALPHA_8)
        val alpha = ByteArray(mw * mh)
        for (i in 0 until mw*mh) {
            val f = buf.float // range 0..1
            alpha[i] = ( (f*255f).toInt().coerceIn(0,255) ).toByte()
        }
        maskBmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(alpha))
        val maskScaled = Bitmap.createScaledBitmap(maskBmp, w, h, true)

        // Draw background
        canvas.drawBitmap(background, 0f, 0f, paint)
        // Draw foreground using mask as alpha
        paint.isFilterBitmap = true
        paint.isAntiAlias = true
        // Use paint to draw foreground respecting mask by using drawBitmap with destination alpha via shader is complex.
        // Simple approach: iterate pixels (slow) — acceptable for demo but heavy for large images.
        val outPixels = IntArray(w*h)
        val fgPixels = IntArray(w*h)
        val bgPixels = IntArray(w*h)
        foreground.getPixels(fgPixels, 0, w, 0, 0, w, h)
        background.getPixels(bgPixels, 0, w, 0, 0, w, h)
        val maskPixels = IntArray(w*h)
        maskScaled.getPixels(maskPixels, 0, w, 0, 0, w, h)
        for (i in 0 until w*h) {
            val a = (maskPixels[i] and 0xff) // 0..255
            val af = a / 255f
            val fg = fgPixels[i]
            val bg = bgPixels[i]
            val r = ( ((fg shr 16 and 0xff) * af) + ((bg shr 16 and 0xff) * (1-af)) ).toInt()
            val g = ( ((fg shr 8 and 0xff) * af) + ((bg shr 8 and 0xff) * (1-af)) ).toInt()
            val b = ( ((fg and 0xff) * af) + ((bg and 0xff) * (1-af)) ).toInt()
            outPixels[i] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
        }
        out.setPixels(outPixels, 0, w, 0, 0, w, h)
        return out
    }

    // Very simple box blur (not the fastest). Replace with RenderScript or GPU blur for production.
    private fun fastBlur(src: Bitmap, radius: Int): Bitmap {
        val w = src.width
        val h = src.height
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(w*h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        val tmp = pixels.copyOf()
        val r = min(radius, 50)
        // horizontal pass
        for (y in 0 until h) {
            var sumR = 0; var sumG = 0; var sumB = 0
            for (x in 0 until w) {
                val p = tmp[y*w + x]
                sumR += (p shr 16) and 0xff
                sumG += (p shr 8) and 0xff
                sumB += p and 0xff
                val left = x - r - 1
                if (left >= 0) {
                    val pl = tmp[y*w + left]
                    sumR -= (pl shr 16) and 0xff
                    sumG -= (pl shr 8) and 0xff
                    sumB -= pl and 0xff
                }
                val right = x + r
                if (right < w) {
                    // add nothing here (we accumulate progressively)
                }
                val count = r + 1
                val nr = (sumR / count).coerceIn(0,255)
                val ng = (sumG / count).coerceIn(0,255)
                val nb = (sumB / count).coerceIn(0,255)
                pixels[y*w + x] = (0xff shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }
}
