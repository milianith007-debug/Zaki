package com.example.iphone17procamera

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

object ColorGrader {
    fun applySimpleFilmLook(src: Bitmap): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bmp)
        val cm = ColorMatrix()
        // contrast
        val contrast = 1.08f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)
        val sat = 1.12f
        val satMatrix = ColorMatrix(); satMatrix.setSaturation(sat)
        cm.postConcat(satMatrix)
        // subtle warm tone
        val warm = ColorMatrix(floatArrayOf(
            1.03f, 0f, 0f, 0f, 0f,
            0f, 1.01f, 0f, 0f, 0f,
            0f, 0f, 0.98f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(warm)

        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(bmp, 0f, 0f, paint)
        return bmp
    }
}
